<?php
    require_once('UserFunctions.0.2.php');
    InsertMode();
?>